class Truck {
public:
    string number, src, dest;
    int capacity, cost;
};
