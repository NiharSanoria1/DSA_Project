class Box {
public:
    string src, dest;
    int id, volume, value;
};
